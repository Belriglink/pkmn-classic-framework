# AdGuard Home DNS Server for Nintendo WFC

This repository contains the configuration and deployment scripts for a custom DNS server that redirects Nintendo WFC traffic to a self-hosted GTS server.

## Architecture

```
NDS → AdGuard Home DNS → GTS Server (101.132.168.11)
                       → Kaeru WFC (178.62.43.212) for authentication
```

## Prerequisites

- GitHub account
- Alibaba Cloud ECS (Linux 3)
- SSH key pair for ECS access
- ECS security group allowing: UDP 53, TCP 53, TCP 3000

## Setup

### 1. Create GitHub Secrets

Go to Repository → Settings → Secrets → Actions and add:

| Secret | Value |
|--------|-------|
| `ECS_HOST` | Your ECS public IP |
| `ECS_USER` | SSH username (usually root) |
| `ECS_SSH_KEY` | Private SSH key for ECS |

### 2. Initial Deployment

Run the "Init Deploy" workflow manually:

1. Go to Actions → Init Deploy → Run workflow
2. This will:
   - Install AdGuard Home on ECS
   - Copy configuration files
   - Configure firewall rules
   - Start AdGuard Home service

### 3. Update Configuration

Simply push changes to the `main` branch. The "Update Configuration" workflow will automatically:

1. Copy updated configuration files to ECS
2. Restart AdGuard Home
3. Run health checks

## Configuration

### DNS Rewrite Rules

Edit `config/custom-rules/nintendo-wfc.txt` to modify DNS mappings:

- GTS domains → `101.132.168.11` (your GTS server)
- Auth domains → `178.62.43.212` (Kaeru WFC)

### Upstream DNS

Edit `config/AdGuardHome.yaml` to change upstream DNS servers:

```yaml
upstream_dns:
  - 178.62.43.212
  - 8.8.8.8
  - 1.1.1.1
```

## Health Check

Run the health check script on ECS:

```bash
bash /tmp/health-check.sh
```

## NDS Configuration

On your Nintendo DS/Wii:
- Primary DNS: Your ECS public IP
- Secondary DNS: 0.0.0.0

## License

MIT