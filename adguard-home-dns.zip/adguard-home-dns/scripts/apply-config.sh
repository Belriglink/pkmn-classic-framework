#!/bin/bash
set -e

CONFIG_DIR="/opt/AdGuardHome/data"

echo "[1/3] Stopping AdGuard Home..."
systemctl stop AdGuardHome

echo "[2/3] Copying configuration files..."
cp -f AdGuardHome.yaml "$CONFIG_DIR/config.yaml"
cp -f custom-rules/nintendo-wfc.txt "$CONFIG_DIR/nintendo-wfc.txt"

echo "[3/3] Restarting AdGuard Home..."
systemctl restart AdGuardHome

echo "[OK] Configuration applied successfully!"