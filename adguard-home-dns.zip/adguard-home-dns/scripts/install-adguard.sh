#!/bin/bash
set -e

echo "[1/3] Installing dependencies..."
apt-get update -qq
apt-get install -y -qq curl unzip dnsutils jq

echo "[2/3] Installing AdGuard Home..."
curl -s -S -L https://raw.githubusercontent.com/AdguardTeam/AdGuardHome/master/scripts/install.sh | sh -s -- -v

echo "[3/3] Configuring firewall..."
ufw allow 53/udp comment "DNS UDP"
ufw allow 53/tcp comment "DNS TCP"
ufw allow 3000/tcp comment "AdGuard Web UI"
ufw reload

echo "[OK] AdGuard Home installed successfully!"