#!/bin/bash

echo "=== Health Check ==="

echo -n "Service status: "
if systemctl is-active --quiet AdGuardHome; then
    echo "RUNNING"
else
    echo "STOPPED"
    exit 1
fi

echo -n "DNS port 53 (UDP): "
if ss -uln | grep -q ":53 "; then
    echo "LISTENING"
else
    echo "NOT LISTENING"
    exit 1
fi

echo -n "DNS resolution test: "
RESULT=$(dig +short @127.0.0.1 gamestats2.gs.nintendowifi.net A 2>/dev/null)
if [ "$RESULT" = "101.132.168.11" ]; then
    echo "OK"
else
    echo "FAILED ($RESULT)"
    exit 1
fi

echo "=== All checks passed ==="
exit 0